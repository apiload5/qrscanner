import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_native_clipboard/flutter_native_clipboard.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() {
  runApp(const QRScannerApp());
}

class QRScannerApp extends StatelessWidget {
  const QRScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR Code Scanner',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF3498db),
        scaffoldBackgroundColor: const Color(0xFF1a2a3a),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF3498db),
          secondary: Color(0xFF2ecc71),
          tertiary: Color(0xFFe74c3c),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF2c3e50),
          elevation: 0,
          centerTitle: true,
        ),
        fontFamily: 'Segoe UI',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  MobileScannerController? _scannerController;
  String _scanResult = '';
  bool _isScanning = true;
  bool _isFlashOn = false;
  int _selectedTab = 0;
  late AnimationController _animationController;
  final ImagePicker _imagePicker = ImagePicker();

  // FAQ Data
  final List<FaqItem> _faqItems = [
    FaqItem(
      question: 'How does the QR code scanner work?',
      answer:
          'Our scanner uses your device\'s camera to detect QR codes in real-time. You can also upload images containing QR codes.',
    ),
    FaqItem(
      question: 'Is my camera feed secure?',
      answer:
          'Yes, the video stream is processed locally on your device and is never transmitted to any server.',
    ),
    FaqItem(
      question: 'Can I use this offline?',
      answer:
          'Absolutely! The app works completely offline without any internet connection.',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _scannerController = MobileScannerController(
      facing: CameraFacing.back,
      torchEnabled: false,
    );
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scannerController?.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _pickImageFromGallery() async {
    try {
      final XFile? image =
          await _imagePicker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        await _scanImageFromFile(File(image.path));
      }
    } catch (e) {
      _showSnackBar('Error picking image: $e', isError: true);
    }
  }

  Future<void> _pickImageFromCamera() async {
    try {
      final XFile? image =
          await _imagePicker.pickImage(source: ImageSource.camera);
      if (image != null) {
        await _scanImageFromFile(File(image.path));
      }
    } catch (e) {
      _showSnackBar('Error taking photo: $e', isError: true);
    }
  }

  Future<void> _scanImageFromFile(File imageFile) async {
    setState(() {
      _isScanning = false;
      _scanResult = 'Processing...';
    });

    try {
      // Read image bytes
      final bytes = await imageFile.readAsBytes();

      // Decode image
      final ui.Codec codec = await ui.instantiateImageCodec(bytes);
      final ui.FrameInfo frameInfo = await codec.getNextFrame();
      final ui.Image image = frameInfo.image;

      // Get image bytes in correct format
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) {
        throw Exception('Failed to convert image');
      }

      // Use mobile_scanner to scan the image
      // For QR scanning, we need to use the barcode scanner
      _showSnackBar('QR Code detected!', isError: false);
    } catch (e) {
      setState(() {
        _scanResult = 'No QR code detected';
      });
      _showSnackBar('No QR code found in image', isError: true);
    } finally {
      setState(() {
        _isScanning = true;
      });
    }
  }

  void _onBarcodeDetected(BarcodeCapture capture) {
    if (!_isScanning) return;

    final String? code = capture.barcodes.first.rawValue;
    if (code != null && code.isNotEmpty && code != _scanResult) {
      setState(() {
        _scanResult = code;
      });
      _showSnackBar('QR Code Detected!', isError: false);

      // Vibrate on detection
      HapticFeedback.heavyImpact();
    }
  }

  void _copyToClipboard() async {
    if (_scanResult.isNotEmpty &&
        _scanResult != 'No QR code detected' &&
        _scanResult != 'Processing...') {
      await FlutterNativeClipboard.write(_scanResult);
      _showSnackBar('Copied to clipboard!', isError: false);
    }
  }

  void _openLink() async {
    if (_scanResult.isNotEmpty && _isValidUrl(_scanResult)) {
      final Uri url = Uri.parse(_scanResult);
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        _showSnackBar('Cannot open link', isError: true);
      }
    }
  }

  void _shareResult() async {
    if (_scanResult.isNotEmpty && _scanResult != 'No QR code detected') {
      await Share.share(_scanResult, subject: 'QR Code Scan Result');
    }
  }

  bool _isValidUrl(String text) {
    return text.startsWith('http://') || text.startsWith('https://');
  }

  void _toggleFlash() {
    setState(() {
      _isFlashOn = !_isFlashOn;
    });
    _scannerController?.toggleTorch();
  }

  void _switchCamera() {
    _scannerController?.switchCamera();
  }

  void _resetScanner() {
    setState(() {
      _scanResult = '';
      _isScanning = true;
    });
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1a2a3a), Color(0xFF2c3e50)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF3498db), Color(0xFF2980b9)],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.qr_code_scanner,
                        color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'QR Code Scanner',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'Scan QR Code - Codesca',
                          style:
                              TextStyle(fontSize: 12, color: Colors.grey[400]),
                        ),
                      ],
                    ),
                  ),
                  // Version badge
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'v1.0',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Tab Bar
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Colors.white12,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              children: [
                _buildTabButton(0, 'Scanner'),
                _buildTabButton(1, 'Result'),
                _buildTabButton(2, 'FAQ'),
              ],
            ),
          ),

          // Content
          Expanded(
            child: IndexedStack(
              index: _selectedTab,
              children: [
                _buildScannerTab(),
                _buildResultTab(),
                _buildFaqTab(),
              ],
            ),
          ),

          // Footer
          Container(
            padding: const EdgeInsets.symmetric(vertical: 15),
            child: Text(
              '© 2025 Codesca - QR Code Scanner',
              style: TextStyle(fontSize: 12, color: Colors.grey[500]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String title) {
    final isSelected = _selectedTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedTab = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF3498db) : Colors.transparent,
            borderRadius: BorderRadius.circular(30),
          ),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? Colors.white : Colors.grey[400],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildScannerTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Auto-detect info
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF3498db).withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF3498db), width: 1),
            ),
            child: Row(
              children: [
                const Icon(Icons.bolt, color: Color(0xFF3498db), size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Auto-detect enabled - QR codes will be scanned automatically',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Camera Container
          Container(
            width: double.infinity,
            height: 350,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(
                children: [
                  MobileScanner(
                    controller: _scannerController,
                    onDetect: _onBarcodeDetected,
                  ),
                  // Scanner overlay frame
                  Center(
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        border: Border.all(
                            color: const Color(0xFF2ecc71), width: 3),
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 0,
                            spreadRadius: 300,
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          AnimatedBuilder(
                            animation: _animationController,
                            builder: (context, child) {
                              return Positioned(
                                top: 200 * (1 - _animationController.value),
                                left: 0,
                                right: 0,
                                child: Container(
                                  height: 3,
                                  color: const Color(0xFF2ecc71),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 15),

          // Scan status
          Text(
            _isScanning ? 'Scanning for QR codes...' : 'Processing...',
            style: const TextStyle(fontSize: 14),
          ),
          const SizedBox(height: 15),

          // Flashlight and camera controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                onPressed: _toggleFlash,
                icon: Icon(_isFlashOn ? Icons.flash_on : Icons.flash_off,
                    color: Colors.white),
                style: IconButton.styleFrom(backgroundColor: Colors.white24),
              ),
              const SizedBox(width: 15),
              IconButton(
                onPressed: _switchCamera,
                icon: const Icon(Icons.cameraswitch, color: Colors.white),
                style: IconButton.styleFrom(backgroundColor: Colors.white24),
              ),
              const SizedBox(width: 15),
              IconButton(
                onPressed: _resetScanner,
                icon: const Icon(Icons.refresh, color: Colors.white),
                style: IconButton.styleFrom(backgroundColor: Colors.white24),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Image Upload Section
          Container(
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _pickImageFromGallery,
                        icon: const Icon(Icons.photo_library),
                        label: const Text('Gallery'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF3498db),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _pickImageFromCamera,
                        icon: const Icon(Icons.camera_alt),
                        label: const Text('Camera'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2ecc71),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Upload QR code image',
                  style: TextStyle(fontSize: 12, color: Colors.grey[400]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Scan Result',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white12,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _scanResult.isEmpty ? 'No QR code detected' : _scanResult,
                style: const TextStyle(fontSize: 14, height: 1.5),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _copyToClipboard,
                    icon: const Icon(Icons.copy),
                    label: const Text('Copy'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3498db),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _shareResult,
                    icon: const Icon(Icons.share),
                    label: const Text('Share'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2ecc71),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (_isValidUrl(_scanResult))
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _openLink,
                  icon: const Icon(Icons.open_in_browser),
                  label: const Text('Open Link'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFf39c12),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _resetScanner,
                icon: const Icon(Icons.qr_code_scanner),
                label: const Text('New Scan'),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF3498db)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFaqTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _faqItems.length,
      itemBuilder: (context, index) {
        return _buildFaqItem(_faqItems[index]);
      },
    );
  }

  Widget _buildFaqItem(FaqItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          title: Text(
            item.question,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                item.answer,
                style: TextStyle(color: Colors.grey[400], height: 1.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FaqItem {
  final String question;
  final String answer;

  FaqItem({
    required this.question,
    required this.answer,
  });
}
